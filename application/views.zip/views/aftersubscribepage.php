<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Nicepage 3.24.4, nicepage.com">
    <meta name="theme-color" content="#ff7043">
    <title>Home</title>
    <link rel="stylesheet" type="text/css"  href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    
<link rel="stylesheet" type="text/css"  href="<?= base_url() . 'assets/home/css/' . 'bootstrap.min.css'; ?>"   media="all"/>
<link rel="stylesheet" type="text/css"  href="<?= base_url() . 'assets/home/css/' . 'custom.css'; ?>"  media="all"/>
<link rel="stylesheet" type="text/css"  href="<?= base_url() . 'assets/home/css/' . 'owl.carousel.min.css'; ?>"   media="all"/>
<link href="<?php echo(base_url() . 'assets/img/animated_favicon.gif'); ?>" rel="icon" type="image/x-icon" />
<script src="http://getbootstrap.com/2.3.2/assets/js/bootstrap-tooltip.js"></script>

<script src='<?= base_url('assets/home/js/bootstrap.bundle.min.js'); ?>'> </script>
<script src="<?= base_url() . 'assets/home/js/' . 'custom.js'; ?>"></script>
<script src="<?= base_url() . 'assets/home/js/' . 'jquery-3.5.1.slim.min.js'; ?>"></script>
<script src="<?= base_url() . 'assets/home/js/' . 'owl.carousel.min.js'; ?>"></script>
<style>
  .home-banner-video {
    position: absolute;
    left: 50%;
    top: 50%;
    min-width: 100%;
    min-height: 100%;
    -webkit-transform: translate(-50%,-50%);
    -moz-transform: translate(-50%,-50%);
    -ms-transform: translate(-50%,-50%);
    transform: translate(-50%,-50%);
    z-index: 0;
}
.home-banner-btn  a{
    text-decoration:none;
}

@media screen and (max-width: 680px) {
    .home-banner-video-bg {
    position: absolute !important;
    left: 0;
    top: 0;
    width: 6200px;
    height: 100%;
    background-size:cover;
    filter: brightness(0.5);
    overflow: hidden;
}
 .home-banner-video {
    position: absolute;
    width: 500px;
    left: -39%;
    height: 578%;
    top: -39%;
    pointer-events: none;
    display: block;
    padding: 0;
    overflow: hidden;
}

}
</style>
<script>
  $(document).ready(function() {
  //initializing tooltip
$('[data-toggle="tooltip"]').tooltip();

});
</script>
</head>
<body class="body">


<header class="header-bg">
        <div class="container">
            <div class="h-social-icons">
                <a class="h-facebook" title="facebook" target="_blank" href="">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a class="h-twitter" title="twitter" target="_blank" href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a class="h-instagram" title="instagram" target="_blank" href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                <a class="h-linkedIn" target="_blank" title="LinkedIn" href="">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
            </div>
            <div class="main-logo">
                <a href="#">
                    <img src="<?php echo base_url('assets/home/images/logo.png');?>" class="logo-image" alt="Logo">
                </a>
            </div>
            <nav class="main-menu">
                <div class="menu-close"><i class="fa fa-times" aria-hidden="true"></i></div>
                <ul class="main-ul">
                    <li class="nav-item">
                        <a class="active" href="<?php echo base_url(); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo base_url(); ?>about-us">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo base_url(); ?>blogList">Blog</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a href="#">Contact Us</a>
                    </li> -->
                    <li class="nav-item">
                        <a href="tel:#" class="icons"><i class="fa fa-phone h-icons" aria-hidden="true"></i></a>
                    </li>
                    <li class="nav-item">
                        <a href="mailto:#" class="icons"><i class="fa fa-envelope h-icons envelope" aria-hidden="true"></i></a>
                    </li>
                </ul>
            </nav>
            <div class="h-login-bg">
                <a href="<?php echo base_url(); ?>signin" class="h-login">LOGIN</a>
                <a href="#" class="mobile-tigger"><i class="fa fa-bars" aria-hidden="true"></i></a>
            </div>

        </div><!-- Container End -->
    </header>

    <section class="home-banner-bg">
        <div class="home-banner-video-bg">
            <div class="home-banner-video" style="background-color: #111;">
                        <iframe class="embed-responsive-item" width="460" height="315"
               src="https://www.youtube.com/embed/eiNvw2ViBds?playlist=eiNvw2ViBds&amp;loop=1&amp;mute=1&amp;showinfo=0&amp;controls=0&amp;start=0&amp;autoplay=1"-->
                frameborder="0" allowfullscreen=""></iframe>-->
            </div>
        </div>

        <div class="container">
            <div class="banner-text">
                <h1>Interview Preparation Program </h1>
                <h4>Get Job Ready</h4>
                <p>Skillpromise offers this incisive and comprehensive program to prepare you on<br>various components
                    of the Job interview process like</p>
            </div>
            <div class="banner-list">
                <div class="list-bg">
                    <p>
                        <span>
                            <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">
                                <g>
                                    <path
                                        d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">
                                    </path>
                                </g>
                            </svg>
                        </span> Aptitude Development Program
                    </p>
                    <p>
                        <span>
                            <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">
                                <g>
                                    <path
                                        d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">
                                    </path>
                                </g>
                            </svg>
                        </span> Group Discussion
                    </p>
                </div>
                <div class="list-bg">
                    <p>
                        <span>
                            <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">
                                <g>
                                    <path
                                        d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">
                                    </path>
                                </g>
                            </svg>
                        </span> Guesstimation
                    </p>
                    <p>
                        <span>
                            <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">
                                <g>
                                    <path
                                        d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">
                                    </path>
                                </g>
                            </svg>
                        </span> Self-Assessment
                    </p>
                </div>
                <div class="list-bg">
                    <p>
                        <span>
                            <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">
                                <g>
                                    <path
                                        d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">
                                    </path>
                                </g>
                            </svg>
                        </span> Employment-Documentation
                    </p>
                    <p>
                        <span>
                            <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">
                                <g>
                                    <path
                                        d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">
                                    </path>
                                </g>
                            </svg>
                        </span> Personal Interview
                    </p>
                </div>
            </div>
            <div class="home-banner-btn">
                <a href="#">Video Tour</a>
                <a href="#">Program Detail</a>
            </div>
        </div>
    </section>
    <!--<section class="home-banner-bg">-->
    <!--    <div class="home-banner-video-bg">-->
    <!--        <div class="home-banner-video" style="background-color: #111;">-->
    <!--            <iframe class="embed-responsive-item" width="460" height="315" -->
    <!--                src="https://www.youtube.com/embed/eiNvw2ViBds?playlist=eiNvw2ViBds&amp;loop=1&amp;mute=1&amp;showinfo=0&amp;controls=0&amp;start=0&amp;autoplay=1"-->
    <!--                frameborder="0" allowfullscreen=""></iframe>-->
                    
    <!--        </div>-->
    <!--    </div>-->

    <!--    <div class="container">-->
    <!--        <div class="banner-text">-->
    <!--            <h1>Interview Preparation Program </h1>-->
    <!--            <h4>Get Job Ready</h4>-->
    <!--            <p>Skillpromise offers this incisive and comprehensive program to prepare you on<br>various components-->
    <!--                of the Job interview process like</p>-->
    <!--        </div>-->
    <!--        <div class="banner-list">-->
    <!--            <div class="list-bg">-->
    <!--                <p>-->
    <!--                    <span>-->
    <!--                        <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">-->
    <!--                            <g>-->
    <!--                                <path-->
    <!--                                    d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">-->
    <!--                                </path>-->
    <!--                            </g>-->
    <!--                        </svg>-->
    <!--                    </span> Aptitude Development Program-->
    <!--                </p>-->
    <!--                <p>-->
    <!--                    <span>-->
    <!--                        <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">-->
    <!--                            <g>-->
    <!--                                <path-->
    <!--                                    d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">-->
    <!--                                </path>-->
    <!--                            </g>-->
    <!--                        </svg>-->
    <!--                    </span> Group Discussion-->
    <!--                </p>-->
    <!--            </div>-->
    <!--            <div class="list-bg">-->
    <!--                <p>-->
    <!--                    <span>-->
    <!--                        <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">-->
    <!--                            <g>-->
    <!--                                <path-->
    <!--                                    d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">-->
    <!--                                </path>-->
    <!--                            </g>-->
    <!--                        </svg>-->
    <!--                    </span> Guesstimation-->
    <!--                </p>-->
    <!--                <p>-->
    <!--                    <span>-->
    <!--                        <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">-->
    <!--                            <g>-->
    <!--                                <path-->
    <!--                                    d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">-->
    <!--                                </path>-->
    <!--                            </g>-->
    <!--                        </svg>-->
    <!--                    </span> Self-Assessment-->
    <!--                </p>-->
    <!--            </div>-->
    <!--            <div class="list-bg">-->
    <!--                <p>-->
    <!--                    <span>-->
    <!--                        <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">-->
    <!--                            <g>-->
    <!--                                <path-->
    <!--                                    d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">-->
    <!--                                </path>-->
    <!--                            </g>-->
    <!--                        </svg>-->
    <!--                    </span> Employment-Documentation-->
    <!--                </p>-->
    <!--                <p>-->
    <!--                    <span>-->
    <!--                        <svg class="u-svg-content" viewBox="0 0 24 24" style="width: 1em; height: 1em;">-->
    <!--                            <g>-->
    <!--                                <path-->
    <!--                                    d="m9.707 19.121c-.187.188-.442.293-.707.293s-.52-.105-.707-.293l-5.646-5.647c-.586-.586-.586-1.536 0-2.121l.707-.707c.586-.586 1.535-.586 2.121 0l3.525 3.525 9.525-9.525c.586-.586 1.536-.586 2.121 0l.707.707c.586.586.586 1.536 0 2.121z">-->
    <!--                                </path>-->
    <!--                            </g>-->
    <!--                        </svg>-->
    <!--                    </span> Personal Interview-->
    <!--                </p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <div class="home-banner-btn">-->
    <!--            <a href="#">Video Tour</a>-->
    <!--            <a href="#">Program Detail</a>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->



    <section class="skillpromise-bg">
        <div class="glb-title">
            <div class="container">
                <h2>Skillpromise Programs</h2>

            </div>
        </div>
        <div class="container">
            <h4>Get Job Ready with <b>Skillpromise Interview Preparation Program</b></h4>
            <p>Skillpromise offers this incisive program to prepare you on various components of the Job Interview
                process like Aptitude Development, Guesstimation, Employment Documentation, Group Discussion,
                Self-Assessment and Personal Interview.</p>
            <div class="row pt-3">
            <?php  
            foreach ($home_packagea as $home_packages)
            {?>
                <div class="col-md-4 col-lg-3   " data-toggle="tooltip" data-placement="right" title="<?php echo $home_packages->description; ?>">
                    <div class="skill-box">
                        <img alt="" src="<?= base_url("$home_packages->image");?>">
                         
                        <h4><?php echo $home_packages->name; ?></h4>
                        <p>6 Branches</p>
                        <a href="<?= base_url("Programs/$home_packages->url");?>" class="glb-btn">Learn More</a>
                               </div>
                </div>
           <?php     }
                ?>

            </div>
        </div>
    </section>
    <!--<section class="skillpromise-bg">-->
    <!--    <div class="glb-title">-->
    <!--        <div class="container">-->
    <!--            <h2>Skillpromise Programs</h2>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="container">-->
    <!--        <h4>Get Job Ready with <b>Skillpromise Interview Preparation Program</b></h4>-->
    <!--        <p>Skillpromise offers this incisive program to prepare you on various components of the Job Interview-->
    <!--            process like Aptitude Development, Guesstimation, Employment Documentation, Group Discussion,-->
    <!--            Self-Assessment and Personal Interview.</p>-->
    <!--        <div class="row pt-3">-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/home/images/a6c6a551-1502-4d3a-8fb2-530f2b89464b.jpg');?>">-->
    <!--                    <h4>Management</h4>-->
    <!--                    <a href="<?= base_url('Programs/20');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/9358999.jpg');?>">-->
    <!--                    <h4>Engineering</h4>-->
    <!--                    <a href="<?= base_url('Programs/18');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/498761438.jpg');?>">-->
    <!--                    <h4>Science</h4>-->
    <!--                    <a href="<?= base_url('Programs/21');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/1493224285.jpg');?>">-->
    <!--                    <h4>Humanities</h4>-->
    <!--                    <a href="<?= base_url('Programs/26');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/796949095.jpg');?>">-->
    <!--                    <h4>Healthcare</h4>-->
    <!--                    <a href="<?= base_url('Programs/22');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/1011037239.jpg');?>">-->
    <!--                    <h4>Commerce</h4>-->
    <!--                    <a href="<?= base_url('Programs/24');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--                           <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/1378699682.jpg');?>">-->
    <!--                    <h4>Hotel Management</h4>-->
    <!--                    <a href="<?= base_url('Programs/25');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/1422710393.jpg');?>">-->
    <!--                    <h4>Journalism & MC</h4>-->
                        
    <!--                    <a href="<?= base_url('Programs/19');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--                            <div class="col-md-4 col-lg-3">-->
    <!--                <div class="skill-box">-->
    <!--                    <img alt="" src="<?= base_url('assets/sub_package_image/573432721.jpg');?>">-->
    <!--                    <h4>Law</h4>-->
    <!--                    <a href="<?= base_url('Programs/23');?>" class="glb-btn">Learn More</a>-->
    <!--                </div>-->
    <!--            </div>-->
                
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
 <section class="testimonials-grp-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="white-bg">
                        <div class="glb-title px-3">
                            <h2>Testimonials</h2>
                        </div>
                        <!-- <div class="testimonials-box-bg">
                            <div class="testimonials-box">
                                <div class="testimonials-img">
                                    <img src="images/aman.png" alt="Aman" />
                                </div>
                                <div class="testimonials-text">
                                    <p> Skillpromise has helped me develop some of the key skills required to make an
                                        individual Industry Ready. Skillpromise modules have helped me a lot throughout
                                        my Recruitment procedure and I successfully secured a final placement with
                                        Khaleej Times, Dubai.</p>
                                    <h5> Aman Khan</h5>
                                    <h6>Student, IMT, Dubai</h6>
                                </div>
                            </div>
                            <div class="testimonials-btns">
                                <a href="#" class="glb-btn">Students</a>
                                <a href="#" class="glb-btn">Academia</a>
                                <a href="#" class="glb-btn">Corporate</a>
                            </div>
                        </div> -->



                        <div class="testimonial-tabbs">
                            <div class="w-100 border">

                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="students" role="tabpanel"
                                        aria-labelledby="students-tab">
                                        <div class="testimonials-box">
                                            <div class="testimonials-img">
<img src="<?php echo base_url('assets/images/aman.png');?>" alt="Aman" />
                                            </div>
                                            <div class="testimonials-text test-head">
                                                <h5> Aman Khan</h5>
                                                <h6>Student, IMT, Dubai</h6>
                                                                                              
                                            </div>
                                            <div class="testimonials-text">
                                                <p> Skillpromise has helped me develop some of the key skills required
                                                    to make an
                                                    individual Industry Ready. Skillpromise modules have helped me a lot
                                                    throughout
                                                    my Recruitment procedure and I successfully secured a final
                                                    placement with
                                                    Khaleej Times, Dubai.</p>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="academia" role="tabpanel"
                                        aria-labelledby="academia-tab">
                                        <div class="testimonials-box">
                                            <div class="testimonials-img">
                                                <img src="<?php echo base_url('assets/images/aman.png');?>" alt="Aman" />
                                            </div>
                                            <div class="testimonials-text test-head">
                                                <h5> Aman Khan</h5>
                                                <h6>Academia</h6>
                                                                                              
                                            </div>
                                            <div class="testimonials-text">
                                                <p> Skillpromise has helped me develop some of the key skills required
                                                    to make an
                                                    individual Industry Ready. Skillpromise modules have helped me a lot
                                                    throughout
                                                    my Recruitment procedure and I successfully secured a final
                                                    placement with
                                                    Khaleej Times, Dubai.</p>
                                                                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="corporate" role="tabpanel"
                                        aria-labelledby="ccorporate-tab">
                                        <div class="testimonials-box">
                                            <div class="testimonials-img">
                                             <img src="<?php echo base_url('assets/images/aman.png');?>" alt="Aman" />
                                            </div>
                                            <div class="testimonials-text test-head">
                                                <h5> Aman Khan</h5>
                                                <h6>Corporate</h6>
                                                                                              
                                            </div>
                                            <div class="testimonials-text">
                                                <p> Skillpromise has helped me develop some of the key skills required
                                                    to make an
                                                    individual Industry Ready. Skillpromise modules have helped me a lot
                                                    throughout
                                                    my Recruitment procedure and I successfully secured a final
                                                    placement with
                                                    Khaleej Times, Dubai.</p>
                                                                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item test-li">
                                        <a class="nav-link active test-btn" id="students-tab" data-toggle="tab" href="#students"
                                            role="tab" aria-controls="students" aria-selected="true">Students</a>
                                    </li>
                                    <li class="nav-item test-li">
                                        <a class="nav-link test-btn" id="academia-tab" data-toggle="tab" href="#academia"
                                            role="tab" aria-controls="academia" aria-selected="false">Academia</a>
                                    </li>
                                    <li class="nav-item test-li">
                                        <a class="nav-link test-btn" id="customerreviews-tab" data-toggle="tab" href="#corporate"
                                            role="tab" aria-controls="customerreviews"
                                            aria-selected="false">Corporate</a>
                                    </li>
                                </ul>



                            </div>
                        </div>



                        <ul class="nav nav-tabs" id="myTab" role="tablist">




                    </div>
                </div>


            <div class="col-md-6">
                <div class="glb-title px-3">
                    <h2>Why choose Skillpromise?</h2>
                </div>
                <div class="skillpromise-box">
                    <div class="single-slider owl-carousel owl-theme">
                        
                        <div class="item">
                            <img src="	https://skillpromise.in/assets/img/WSPconvinience.png" />
                            <h3>CONVENIENCE</h3>
                            <p class="px-3 mb-0">Skillpromise offers Self-Paced Online Programs. Self-paced learning means you can learn in your own time and schedule. You don’t need to complete the same assignments or learn at the same time as others. You can proceed from one topic or segment to the next at your speed
</p>
                        </div>
                        <div class="item">
                            <img src="https://skillpromise.in/assets/img/WSPinformedDecisionMaking.png" />
                            <h3>Informed Decision Making</h3>
                            <p class="px-3 mb-0">Skillpromise Programs will equips you with a clear picture about your personality attributes, needs, goals etc., assessments that you need to prepare for like Aptitude, domain etc., and documents that you need to prepare like CV, Cover Letter, Self-Introduction etc. In light of all this well researched information, you are able to make informed decisions
</p>
                        </div>
                        <div class="item">
                            <img src="https://skillpromise.in/assets/img/WSPenhancedConfidenceLevels.png" />
                            <h3>Enhanced Confidence levels</h3>
                            <p class="px-3 mb-0">Skillpromise Programs will engage you in in-depth Self-Assessment, help you create persuasive CV and cover letter and  provide in-depth coaching on HR, Behavioral and Technical questions asked in the interviews. This will enable you to make informed decisions and pursue your goals with enhanced confidence.
</p>
                        </div>
                        <div class="item">
                            <img src="https://skillpromise.in/assets/img/WSPinstantReturnOnLearning.png" />
                            <h3>Instant Return on Learning</h3>
                            <p class="px-3 mb-0">Skillpromise Programs will enable you to use your learning immediately. As soon as you finish learning something on Skillpromise, you know the impact of your learnings on your future behaviour, decisions and communication. This will help you make a course correction immediately, if required.
</p>
                        </div>
                        <div class="item">
                            <img src="https://skillpromise.in/assets/img/WSPeasyInformationAccess.png" />
                            <h3>Easy Information Access</h3>
                            <p class="px-3 mb-0">Skillpromise Programs enable you to document your reflection logs, learnings and your action plans, by making you fill action sheets or worksheets, throughout the program. This information can be assessed from the Dashboard anytime.
</p>
                        </div>
                        <div class="item">
                            <img src="https://skillpromise.in/assets/img/WSPcomprehensiveContent.png" />
                            <h3>Comprehensiveness of Content</h3>
                            <p class="px-3 mb-0">Skillpromise Programs offer very comprehensive content and coaching on various elements of interview preparation process. Comprehensiveness provides you with the optimal reach and depth of content required for you to succeed in your job search endeavors
</p>
                        </div>
                        <div class="item">
                            <img src="https://skillpromise.in/assets/img/WSPprivacy.png" />
                            <h3>Privacy</h3>
                            <p class="px-3 mb-0">Reflective learning in a classroom environment may make you uncomfortable as you may not like to talk about your learning gaps or share personal information with everybody. You do not have to worry about all these things when you are taking the course online.
</p>
                        </div>
                      
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--    <section class="testimonials-grp-bg">-->
<!--        <div class="container">-->
<!--            <div class="row">-->
<!--                <div class="col-md-6">-->
<!--                    <div class="white-bg">-->
<!--                        <div class="glb-title px-3">-->
<!--                            <h2>Testimonials</h2>-->
<!--                        </div>-->
                        <!-- <div class="testimonials-box-bg">
<!--                            <div class="testimonials-box">-->
<!--                                <div class="testimonials-img">-->
<!--                                    <img src="images/aman.png" alt="Aman" />-->
<!--                                </div>-->
<!--                                <div class="testimonials-text">-->
<!--                                    <p> Skillpromise has helped me develop some of the key skills required to make an-->
<!--                                        individual Industry Ready. Skillpromise modules have helped me a lot throughout-->
<!--                                        my Recruitment procedure and I successfully secured a final placement with-->
<!--                                        Khaleej Times, Dubai.</p>-->
<!--                                    <h5> Aman Khan</h5>-->
<!--                                    <h6>Student, IMT, Dubai</h6>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                            <div class="testimonials-btns">-->
<!--                                <a href="#" class="glb-btn">Students</a>-->
<!--                                <a href="#" class="glb-btn">Academia</a>-->
<!--                                <a href="#" class="glb-btn">Corporate</a>-->
<!--                            </div>-->
<!--                        </div> -->



<!--                        <div class="testimonial-tabbs">-->
<!--                            <div class="w-100 border">-->

<!--                                <div class="tab-content" id="myTabContent">-->
<!--                                    <div class="tab-pane fade show active" id="students" role="tabpanel"-->
<!--                                        aria-labelledby="students-tab">-->
<!--                                        <div class="testimonials-box">-->
<!--                                            <div class="testimonials-img">-->
<!--                                                <img src="<?= base_url('assets/home/images/aman.png');?>" alt="Aman" />-->
<!--                                            </div>-->
<!--                                            <div class="testimonials-text">-->
<!--                                                <p> Skillpromise has helped me develop some of the key skills required-->
<!--                                                    to make an-->
<!--                                                    individual Industry Ready. Skillpromise modules have helped me a lot-->
<!--                                                    throughout-->
<!--                                                    my Recruitment procedure and I successfully secured a final-->
<!--                                                    placement with-->
<!--                                                    Khaleej Times, Dubai.</p>-->
<!--                                                <h5> Aman Khan</h5>-->
<!--                                                <h6>Student, IMT, Dubai</h6>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                    <div class="tab-pane fade" id="academia" role="tabpanel"-->
<!--                                        aria-labelledby="academia-tab">-->
<!--                                        <div class="testimonials-box">-->
<!--                                            <div class="testimonials-img">-->
<!--                                                <img src="<?= base_url('assets/home/images/aman.png');?>" alt="Aman" />-->
<!--                                            </div>-->
<!--                                            <div class="testimonials-text">-->
<!--                                                <p> Skillpromise has helped me develop some of the key skills required-->
<!--                                                    to make an-->
<!--                                                    individual Industry Ready. Skillpromise modules have helped me a lot-->
<!--                                                    throughout-->
<!--                                                    my Recruitment procedure and I successfully secured a final-->
<!--                                                    placement with-->
<!--                                                    Khaleej Times, Dubai.</p>-->
<!--                                                <h5> Aman Khan</h5>-->
<!--                                                <h6>Academia</h6>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                    <div class="tab-pane fade" id="corporate" role="tabpanel"-->
<!--                                        aria-labelledby="ccorporate-tab">-->
<!--                                        <div class="testimonials-box">-->
<!--                                            <div class="testimonials-img">-->
<!--                                                <img src="<?= base_url('assets/home/images/aman.png');?>" alt="Aman" />-->
<!--                                            </div>-->
<!--                                            <div class="testimonials-text">-->
<!--                                                <p> Skillpromise has helped me develop some of the key skills required-->
<!--                                                    to make an-->
<!--                                                    individual Industry Ready. Skillpromise modules have helped me a lot-->
<!--                                                    throughout-->
<!--                                                    my Recruitment procedure and I successfully secured a final-->
<!--                                                    placement with-->
<!--                                                    Khaleej Times, Dubai.</p>-->
<!--                                                <h5> Aman Khan</h5>-->
<!--                                                <h6>Corporate</h6>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </div>-->


<!--                                <ul class="nav nav-tabs" id="myTab" role="tablist">-->
<!--                                    <li class="nav-item test-li">-->
<!--                                        <a class="nav-link active test-btn" id="students-tab" data-toggle="tab" href="#students"-->
<!--                                            role="tab" aria-controls="students" aria-selected="true">Students</a>-->
<!--                                    </li>-->
<!--                                    <li class="nav-item test-li">-->
<!--                                        <a class="nav-link test-btn" id="academia-tab" data-toggle="tab" href="#academia"-->
<!--                                            role="tab" aria-controls="academia" aria-selected="false">Academia</a>-->
<!--                                    </li>-->
<!--                                    <li class="nav-item test-li">-->
<!--                                        <a class="nav-link test-btn" id="customerreviews-tab" data-toggle="tab" href="#corporate"-->
<!--                                            role="tab" aria-controls="customerreviews"-->
<!--                                            aria-selected="false">Corporate</a>-->
<!--                                    </li>-->
<!--                                </ul>-->



<!--                            </div>-->
<!--                        </div>-->



<!--                        <ul class="nav nav-tabs" id="myTab" role="tablist">-->




<!--                    </div>-->
<!--                </div>-->
<!--               <div class="col-md-6">-->
<!--                    <div class="glb-title px-3">-->
<!--                        <h2>Why choose Skillpromise?</h2>-->
<!--                    </div>-->
<!--                    <div class="skillpromise-box">-->
<!--                        <div class="single-slider owl-carousel owl-theme">-->
<!--                            <div class="item">-->
<!--                            <img src="<?php echo(base_url() . 'assets/sub_package_image/573432721.jpg'); ?>" />-->
<!--                                <h3> CONVENIENCE</h3>-->
<!--                                <p class="px-3 mb-0">-->
<!--Skillpromise offers Self-Paced Online Programs. Self-paced learning means you can learn in your own time and schedule. You don’t need to complete the same assignments or learn at the same time as others. You can proceed from one topic or segment to the next at your speed-->
<!--                                </p>-->
<!--                            </div>-->
<!--                            <div class="item">-->
<!--                                <img src="<?php echo(base_url() . 'assets/img/' . 'bannerNew2.jpg'); ?>" />-->
<!--                                <h3> CONVENIENCE</h3>-->
<!--                                <p class="px-3 mb-0">Skillpromise Programs will equips you with a clear picture about your personality attributes, needs, goals etc., assessments that you need to prepare for like Aptitude, domain etc., and documents that you need to prepare like CV, Cover Letter, Self-Introduction etc. In light of all this well researched information, you are able to make informed decisions-->
<!--</p>-->
<!--                            </div>-->
<!--                            <div class="item">-->
<!--  <img src="<?php echo(base_url() . 'assets/img/' . 'etiquette.png'); ?>" />-->
<!--                                <h3> CONVENIENCE</h3>-->
<!--                                <p class="px-3 mb-0">Skillpromise offers Self-Paced Online Programs. Self-paced learning-->
<!--                                    means you can learn in your own time and schedule. You don’t need to complete the-->
<!--                                    same assignments or learn at the same time as others. You can proceed from one topic-->
<!--                                    or segment to the next at your speed</p>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->


    <!--<section class="home-form-grp-bg">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-md-6">-->
    <!--                <div class="grey-bg">-->
    <!--                    <div class="glb-title px-3">-->
    <!--                        <h2> FREE Assessment Centre</h2>-->
    <!--                    </div>-->
    <!--                                       <div class="single-slider owl-carousel owl-theme">-->
    <!--                    <div class="item">-->
    <!--                        <div class="asse-img">-->
    <!--                            <img src="<?php echo(base_url() . 'assets/img/' . 'Wellness.jpeg'); ?>" />-->
    <!--                        </div>-->
    <!--                        <div class="asse-text">-->
    <!--                            <h3> How are You feeling today?</h3>-->
    <!--                            <p>Wellness Assessment will help you improve your awareness about your wellness and also help you to reflect on components of Wellness that you may not have considered before</p>-->
    <!--                            <a href="<?php  echo(base_url() . "home_sheets/sheets/45"); ?>" class="glb-btn">Learn More</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="item">-->
    <!--                        <div class="asse-img">-->
    <!--                            <img src="<?php echo(base_url() . 'assets/img/' . 'bannerNew2.jpg'); ?>" />-->
    <!--                        </div>-->
    <!--                        <div class="asse-text">-->
    <!--                            <h3>How good are your CREDIBILITY BUILDING Skills?</h3>-->
    <!--                            <p>Take this quick assessment to explore your understanding of various techniques of CREDIBILITY BUILDING. </p>-->
    <!--                            <a href="<?php  echo(base_url() . "home_sheets/sheets/61"); ?>" class="glb-btn">Learn More</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="item">-->
    <!--                        <div class="asse-img">-->
    <!--                            <img src="<?php echo(base_url() . 'assets/img/' . 'etiquette.png'); ?>" />-->
    <!--                        </div>-->
    <!--                        <div class="asse-text">-->
    <!--                            <h3>Mind your ETIQUETTE</h3>-->
    <!--                            <p>Take this assessment to explore your understanding of various types of ETIQUETTE like Email Etiquette, Social Etiquette, Dining Etiquette, Telephone Etiquette and Business Etiquette</p>-->
    <!--                            <a href="<?php  echo(base_url() . "home_sheets/sheets/45"); ?>" class="glb-btn">Learn More</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-6">-->
    <!--                <div class="grey-bg">-->
    <!--                    <div class="glb-title px-3">-->
    <!--                        <h2>FREE Email Newsletter</h2>-->
    <!--                    </div>-->
    <!--                    <div class="form-box-bg">-->
    <!--                        <div class="form-content">-->
    <!--                            <p>Signup for our free email newsletter and get our <span-->
    <!--                                    class="u-text-palette-1-base">ART OF BUILDING CREDIBILITY e-Book</span> FREE as-->
    <!--                                the Subscription bonus</p>-->
    <!--                            <form action="https://nicepage.com/editor/Forms/Process" method="POST" class=""-->
    <!--                                source="email" name="form">-->
    <!--                                <input type="hidden" id="siteId" name="siteId" value="680585">-->
    <!--                                <input type="hidden" id="pageId" name="pageId" value="680593">-->
    <!--                                <div class="form-group">-->
    <!--                                    <input type="text" placeholder="Name" id="name-b360" name="name"-->
    <!--                                        class="form-control" required="">-->
    <!--                                </div>-->
    <!--                                <div class="form-group">-->
    <!--                                    <input type="email" placeholder="Email" id="email-b360" name="email"-->
    <!--                                        class="form-control" required="">-->
    <!--                                </div>-->
    <!--                                <div class="form-submit">-->
    <!--                                    <a href="#" class="glb-btn">Subscribe</a>-->
    <!--                                    <a href="#" class="reverse-btn">Privacy Policy</a>-->
    <!--                                    <input type="submit" value="submit" class="u-form-control-hidden d-none">-->
    <!--                                </div>-->
    <!--                            </form>-->
    <!--                        </div>-->
    <!--                        <div class="form-img">-->
    <!--                            <img src="<?= base_url('assets/home/images/ebook.jpeg');?>" alt="" />-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <section class="home-form-grp-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="grey-bg">
                        <div class="glb-title px-3">
                            <h2> FREE Assessment Centre</h2>
                        </div>
                        <div class="single-slider owl-carousel owl-theme new-slider">
                            <div class="item">
                                <div class="asse-img">
                                    <img src="<?php echo(base_url() . 'assets/img/' . 'Wellness.jpeg'); ?>" />
                                </div>
                                <div class="asse-text">
                                    <h3> How are You feeling today?</h3>
                                    <p>This Wellness Assessment will help you improve your awareness about your wellness
                                        and also help you to reflect on components of Wellness that you may not have
                                        considered before</p>
                                    <a href="<?php  echo(base_url() . "home_sheets/sheets/45"); ?>" class="glb-btn btn-right">Learn More</a>
                                </div>
                            </div>
                            <div class="item">
                                <div class="asse-img">
                                    <img src="<?php echo(base_url() . 'assets/img/' . 'bannerNew2.jpg'); ?>" />
                                </div>
                                <div class="asse-text">
                                    <h3> How are You feeling today?</h3>
                                    <p>This Wellness Assessment will help you improve your awareness about your wellness
                                        and also help you to reflect on components of Wellness that you may not have
                                        considered before</p>
                                    <a href="<?php  echo(base_url() . "home_sheets/sheets/61"); ?>" class="glb-btn btn-right">Learn More</a>
                                </div>
                            </div>
                            <div class="item">
                                <div class="asse-img">
                                    <img src="<?php echo(base_url() . 'assets/img/' . 'bannerNew2.jpg'); ?>" />
                                </div>
                                <div class="asse-text">
                                    <h3> How are You feeling today?</h3>
                                    <p>This Wellness Assessment will help you improve your awareness about your wellness
                                        and also help you to reflect on components of Wellness that you may not have
                                        considered before</p>
                                    <a href="<?php  echo(base_url() . "home_sheets/sheets/45"); ?>" class="glb-btn btn-right">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="grey-bg">
                        <div class="glb-title px-3">
                            <h2>FREE Email Newsletter</h2>
                        </div>
                        <div class="form-box-bg">
                            <div class="form-content">
                                <p>Signup for our free email newsletter and get our <span
                                        class="u-text-palette-1-base">ART OF BUILDING CREDIBILITY e-Book</span> FREE as
                                    the Subscription bonus</p>
                                 <form action="<?php echo base_url() . 'subscribNewsLetter'; ?>" method="POST" class="" source="email" name="form">
                                    <!--<input type="hidden" id="siteId" name="siteId" value="680585">-->
                                    <!--<input type="hidden" id="pageId" name="pageId" value="680593">-->
                                    <div class="form-group">
                                        <input type="text" placeholder="Name" id="name-b360" name="first_name"
                                            class="form-control" required="">
                                    </div>
                                    <div class="form-group">
                                        <input type="email" placeholder="Email" id="email-b360" name="email"
                                            class="form-control" required="">
                                    </div>
                                    <div class="form-submit">
                                        <!--<a href="#" class="glb-btn">Subscribe</a>-->
                                         <button type="submit" class="glb-btn">Subscribe</button>
                                        <a href="<?php echo(base_url() . "privacy-policy"); ?>" class="reverse-btn">Privacy Policy</a>
                                        <input type="submit" value="submit" class="u-form-control-hidden d-none">
                                    </div>
                                </form>
                            </div>
                            <div class="form-img">
                                <img src="<?php echo(base_url() . 'assets/img/' . 'ebook.jpeg'); ?>" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php  $this->load->view('home_footer'); ?>

</body>
</html>