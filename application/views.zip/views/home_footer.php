<footer class="footer-bg">
        <div class="container">
            <div class="footer-links">
                <div class="row">
                    <div class="col-md-auto">
                        <h3>About Skill Promise</h3>
                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-md-auto">
                        <h3>Programs</h3>
                        <ul>
                            <li><a href="#">Aptitude Development Program</a></li>
                        </ul>
                    </div>
                    <div class="col-md-auto">
                        <h3>Privacy</h3>
                        <ul>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms of Use</a></li>
                        </ul>
                    </div>
                    <div class="col-md-auto">
                        <h3>Testimonials</h3>
                        <ul>
                            <li><a href="#">Academia</a></li>
                            <li><a href="#">Corporate</a></li>
                            <li><a href="#">Student</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row copyright">
                <div class="col-auto mr-auto">
                    <p>© by Sana Skillpromise Education Private Limited. | All Rights Reserved. | Disclaimer</p>
                </div>
                <div class="col-auto">
                    <p>Powered by Lexicon Consultants Pvt. Ltd.</p>
                </div>
            </div>
        </div>
        <!-- <div class="footer-bottom text-center">
            <p>
                <a class="u-link" href="https://nicepage.com/website-templates" target="_blank">Website Templates</a>
                <span>created with</span>
                <a class="u-link" href="https://nicepage.com/" target="_blank">Website Builder Software</a>.
            </p>
        </div> -->
    </footer>
            <script src="<?= base_url('assets/home/js/jquery-3.5.1.slim.min.js');?>"></script>
    <script src="<?= base_url('assets/home/js/bootstrap.bundle.min.js');?>"></script>
    <script src="<?= base_url('assets/home/js/owl.carousel.min.js');?>"></script>
    <script src="<?= base_url('assets/home/js/custom.js');?>"></script>
