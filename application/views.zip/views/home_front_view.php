<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Nicepage 3.24.4, nicepage.com">
    <meta name="theme-color" content="#ff7043">
    <title>Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <!--<link rel="stylesheet" href="<?php echo(base_url() . 'assets/css/' . 'bootstrap1.min.css'); ?>">-->
    <!--<link rel="stylesheet" href="<?php echo(base_url() . 'assets/css/' . 'owl.carousel.min.css'); ?>">-->
    <!--<link rel="stylesheet" href="<?php echo(base_url() . 'assets/css/' . 'custom.css'); ?>">-->
    
<link rel="stylesheet" href="<?php echo(base_url() . 'assets/home/css/' . 'bootstrap.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo(base_url() . 'assets/home/css/' . 'custom.css'); ?>" />
<link rel="stylesheet" href="<?php echo(base_url() . 'assets/home/css/' . 'owl.carousel.min.css'); ?>" />

<script src='<?php echo base_url(); ?>assets/home/js/bootstrap.bundle.min.js'></script>
<script src="<?php echo(base_url() . 'assets/home/js/' . 'custom.js'); ?>"></script>
<script src="<?php echo(base_url() . 'assets/home/js/' . 'jquery-3.5.1.slim.min.js'); ?>"></script>
<script src="<?php echo(base_url() . 'assets/home/js/' . 'owl.carousel.min.js'); ?>"></script>
</head>
<body>
<!--<header class=" header-bg">-->
 
       
      
        <!--</div>-->
    <!--<div class="container">-->
       
    <!--</div>-->
<!--<div class="container">    -->
<!-- Container End -->
        <!--<nav class="main-menu">-->
        <!--    <div class="menu-close"><i class="fa fa-times" aria-hidden="true"></i></div>-->
        <!--    <ul class="main-ul">-->
        <!--        <li class="nav-item">-->
        <!--            <a class="active" href="<?php echo base_url(); ?>">Home</a>-->
        <!--        </li>-->
        <!--        <li class="nav-item">-->
        <!--            <a href="<?php echo base_url(); ?>about-us">About Us</a>-->
        <!--        </li>-->
        <!--        <li class="nav-item">-->
        <!--            <a href="<?php echo base_url(); ?>blogList">Blog</a>-->
        <!--        </li>-->
        <!--        <li class="nav-item">-->
        <!--            <a href="<?php echo base_url(); ?>contact-us">Contact Us</a>-->
        <!--        </li>-->
        <!--    </ul>-->
        <!--</nav>-->
<!--   <nav class="container navbar navbar-expand-md navbar-light">-->
<!--        <div class="main-logo">-->
<!--            <a href="<?php echo base_url(); ?>">-->
<!--                <img src="<?php echo(base_url() . 'assets/images/logo.png'); ?>" class="logo-image" alt="Logo">-->
<!--            </a>-->
<!--        </div>-->
<!--          <button class="navbar-toggler"  type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">-->
<!--    <span class="navbar-toggler-icon"></span>-->
<!--  </button>-->
<!--   <div class="collapse navbar-collapse" id="navbarSupportedContent">-->
<!--   <nav class="main-menu">-->
            <!--<div class="menu-close"><i class="fa fa-times" aria-hidden="true"></i></div>-->
<!--            <ul class="main-ul navbar-nav mr-auto">-->
<!--                <li class="nav-item">-->
<!--                    <a class="active" href="<?php echo base_url(); ?>">Home</a>-->
<!--                </li>-->
<!--                <li class="nav-item">-->
<!--                    <a href="<?php echo base_url(); ?>about-us">About Us</a>-->
<!--                </li>-->
<!--                <li class="nav-item">-->
<!--                    <a href="<?php echo base_url(); ?>blogList">Blog</a>-->
<!--                </li>-->
<!--                <li class="nav-item">-->
<!--                    <a href="<?php echo base_url(); ?>contact-us">Contact Us</a>-->
<!--                </li>-->
<!--            </ul>-->
       
<!--        </nav>-->
<!--    <div class="h-login-bg "  >-->
<!--            <a style="float:right;" href="<?php echo base_url(); ?>signin" class="h-login">LOGIN</a>-->
            
            <!--<a href="#" class="mobile-tigger"><i class="fa fa-bars" aria-hidden="true"></i></a>-->
<!--        </div>-->
<!--         <div class="h-social-icons" >-->
<!--            <a class="h-facebook" title="facebook" target="_blank" href="https://www.facebook.com/skillpromisetool">-->
<!--                <i class="fa fa-facebook" aria-hidden="true"></i>-->
<!--            </a>-->
<!--            <a class="h-twitter" title="twitter" target="_blank" href="https://twitter.com/skillpromise">-->
<!--                <i class="fa fa-twitter" aria-hidden="true"></i>-->
<!--            </a>-->
<!--            <a class="h-instagram" title="instagram" target="_blank" href="">-->
<!--                <i class="fa fa-instagram" aria-hidden="true"></i>-->
<!--            </a>-->
<!--            <a class="h-linkedIn" target="_blank" title="LinkedIn" href="https://www.linkedin.com/company/skill-promise/">-->
<!--                <i class="fa fa-linkedin" aria-hidden="true"></i>-->
<!--            </a>-->
<!--        </div>  -->
<!--    </div>-->
<!-- </nav>-->
<!--</header>-->

<header class="header-bg">
        <div class="container">
            <div class="h-social-icons">
                <a class="h-facebook" title="facebook" target="_blank" href="">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a class="h-twitter" title="twitter" target="_blank" href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a class="h-instagram" title="instagram" target="_blank" href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                <a class="h-linkedIn" target="_blank" title="LinkedIn" href="">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
            </div>
            <div class="main-logo">
                <a href="#">
                    <img src="<?php echo base_url('assets/home/images/logo.png');?>" class="logo-image" alt="Logo">
                </a>
            </div>
            <nav class="main-menu">
                <div class="menu-close"><i class="fa fa-times" aria-hidden="true"></i></div>
                <ul class="main-ul">
                    <li class="nav-item">
                        <a class="active" href="<?php echo base_url(); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo base_url(); ?>about-us">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo base_url(); ?>blogList">Blog</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a href="#">Contact Us</a>
                    </li> -->
                    <li class="nav-item">
                        <a href="tel:#" class="icons"><i class="fa fa-phone h-icons" aria-hidden="true"></i></a>
                    </li>
                    <li class="nav-item">
                        <a href="mailto:#" class="icons"><i class="fa fa-envelope h-icons envelope" aria-hidden="true"></i></a>
                    </li>
                </ul>
            </nav>
            <div class="h-login-bg">
                <a href="<?php echo base_url(); ?>signin" class="h-login">LOGIN</a>
                <a href="#" class="mobile-tigger"><i class="fa fa-bars" aria-hidden="true"></i></a>
            </div>

        </div><!-- Container End -->
    </header>
