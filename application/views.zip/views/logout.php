<?php

session_unset();
$_SESSION['msg_str'] = "You have been Sucessfully Logged Out.";
$_SESSION['msg_str'] = "You have been Sucessfully Logged Out.";
header('Location: ' . base_url());
?>

