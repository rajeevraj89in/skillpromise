<?php
$this->load->view('header_view');
$this->load->view('manager_left_view');
?>

<!--content panel start -->
<section class="col-md-9">
    <div class="dooble-border">
        <div class="panel">
            <h1>About managing this site</h1>
        </div><!-- end page header -->
        <p class="lead text-justify">This page is a <mark>Manager landing page</mark>. Here you can write welcome note for manager. From this page manager can manage "program, sub program, quiz, questions, lesson" and other things by clicking on the left sidebar link.</p>
        <a href="" class="btn btn-large btn-success">Click Me</a>
    </div><!-- end well -->
</section><!-- end col-md-9 -->
<!--end content panel start -->

</div><!-- end bigCallout-->

<!-- End Content and Sidebar
===================================================== -->
</div><!-- end main -->

<?php $this->load->view('footer_view'); ?>
<?php $this->load->view('html_end_view'); ?>