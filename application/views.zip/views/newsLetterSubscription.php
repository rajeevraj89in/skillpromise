<!--news letter inner page-->

        <div class="" >
                                            <h3 id="free_news" style="border:1px solid green;padding:3% 5% 3% 5%;width:100%;font-size:20px;height:43px;background-color:green;color:white;text-align:center;margin:0%">FREE Email Newsletter </h3>
            <div class="row">

              <div class="col-xs-8 col-sm-8 col-md-8">



                <p class="textstyle text-justify" style="font-size:14px;">Signup for our free email newsletter and get our <span style="color:orange;">ART OF BUILDING CREDIBILITY e-BOOK  </span> FREE as a subscription bonus</p>
                <form action="<?php echo base_url() . 'subscribNewsLetter'; ?>" id="news_letter" method="post">
                                <input id="first_name" name="first_name" class="form-control inputbox" placeholder="Name" type="text" data-validation-required-message="Please enter your first name." required="" aria-invalid="false"/>
                                <input id="email" name="email" class="form-control inputbox" placeholder="Email" type="email" data-validation-required-message="Please enter your email address." required="" aria-invalid="false"/>

                                <div class="policy-wrap">
                                    <button  id="subsc" style="background-color:white !important;border:1px solid black !important;color:black !important;border-radius:0px !important;margin: 20% 0 24px;padding: 7px 15px;font-size:14px;">Subscribe</button>
                                        <p class="policy"  style="margin-top:8% !important;"><a href="<?php echo(base_url() . "privacy-policy"); ?>" class="text-right"  style="color:blue;">Privacy Policy</a></p>
                                </div>

                            </form>

            </div>
            <div class="col-xs-4 col-sm-4 col-md-4">
                            <!--<img class="img-responsive" src="<?php //echo(base_url() . 'assets/img/' . 'newsL-img.jpg'); ?>" >-->
                            
                        <img class="img-responsive" src="<?php echo(base_url() . 'assets/img/' . 'home-email-subscribe-image.png'); ?>" style="height:209px;width:100%;margin-top:11%;">
                       
                            </div>

            <!--<div class="col-xs-12 col-sm-12 col-md-12">-->
            <!--        <div class="row">-->

            <!--            <div class="col-xs-8 col-sm-8 col-md-8">-->


                            


            <!--            </div>-->
                        
            <!--        </div>-->
            <!--    </div>-->

        </div>



</div>
<!--news letter inner end-->
<!--Modal -->
<div class = "modal fade" id = "newLetter_modal"   data-backdrop="static" data-keyboard="false">
    <div class = "modal-dialog" role = "document">
        <div class = "modal-content">
            <div class = "modal-header">
                <button type = "button" class = "close" data-dismiss = "modal" aria-label = "Close"><span aria-hidden = "true">&times;
                    </span></button>
                <!--h4 class = "modal-title" id = "myModalLabel">Modal title</h4-->
            </div>
            <div class = "modal-body">
                <div class = "row">
                    <div class = "col-md-8">
                        <h4>Thank you for subscribing to our Email Newsletter. Please follow the following steps to complete your signup process:</h4>
                        <ul class = "custom">
                            <li>Check for our Email in your Inbox and in case it is not there, check your Spam folder.</li>
                            <li>Click the link “Confirm” in the Email that you will receive from us.</li>
                            <li>Download your Art of Building e-Book.</li>



                        </ul>
                    </div>
                    <div class = "col-md-4">
                        <img class = "img-responsive" src = "<?php echo(base_url() . 'assets/img/' . 'art-of-building.png'); ?>" ><br>

                    </div>
                </div>
            </div>
            <!--div class = "modal-footer">
            <button type = "button" class = "btn btn-default" data-dismiss = "modal">Close</button>
            <button type = "button" class = "btn btn-primary">Save changes</button>
            </div-->
        </div>
    </div>
</div>
<!--Modal end-->



 <script>
//     $(document).ready(function () {
//         $('#subsc').click(function (e) {

//             var datastr = {};
//             datastr['first_name'] = $('#first_name').val();
//             datastr['email'] = $('#email').val();


//             if (datastr['first_name'] != '' && datastr['email'] != '') {

//                 $.ajax({

//                     type: "POST",
//                     url: "<?php echo base_url(); ?>subscribNewsLetter/",
//                     data: datastr,
//                     success: function (data) {
//                         $('#newLetter_modal').modal('show');
//                     }

//                 });
//             }

//         }
//         );
//     });
// // $('#newLetter_modal').modal({
// //     backdrop: 'static',
// //     keyboard: false
// // })
// </script>



<!--ALTER TABLE `news_letter` CHANGE `is_mailconfirm` `is_mailconfirm` ENUM('0','1','2') NULL DEFAULT '0' COMMENT 'Pending=2,Subscribed=1 & Unsubscribed=0;';-->







