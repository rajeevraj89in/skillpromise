<?php

//require(APPPATH . '/razorpay-php/config.php');
session_start();

require(APPPATH . '/razorpay-php/Razorpay.php');

//use Razorpay\Api as RazorpayApi;
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false) {
    $api = new Api("rzp_test_jkNt9TKk2upOcG", "JLLqBB8Tb3L7ycF8GXKeom7n");

    try {
        $_POST['razorpay_signature'] = "ee0a3edebeb4be41bafa3bc0a39069d7845a5c37760b863405049de80b5fe92d";
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']

//            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
//            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
//            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    } catch (SignatureVerificationError $e) {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true) {
    $html = "<p>Your payment was successful</p>
             <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";
} else {
    $html = "<p>Your payment failed</p>
             <p>{$error}</p>";
}

echo $html;
